package com.prince.model;

public class Student {

	private long roll;
	private String name;
	private int stander;
	
	

	public Student(long roll, String name, int stander) {
		super();
		this.roll = roll;
		this.name = name;
		this.stander = stander;
	}

	public Long getRoll() {
		return roll;
	}

	public void setRoll(Long roll) {
		this.roll = roll;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getStander() {
		return stander;
	}

	public void setStander(Integer stander) {
		this.stander = stander;
	}

	@Override
	public String toString() {
		return "Student [roll=" + roll + ", name=" + name + ", stander=" + stander + "]";
	}
}
