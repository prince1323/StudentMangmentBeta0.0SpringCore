package com.prince.respository;

import java.util.*;

import org.springframework.stereotype.Component;

import com.prince.model.*;


@Component
public class StudentRepository {

	private final List<Student> studentList = new ArrayList<>();

	public void addStudent(Student student) {
		studentList.add(student);
		System.out.println("Saved: " + student);
	}

	public List<Student> findAll() {
		return studentList;
	}

}
