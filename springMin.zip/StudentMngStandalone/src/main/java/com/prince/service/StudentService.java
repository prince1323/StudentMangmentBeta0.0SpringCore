package com.prince.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.prince.model.Student;
import com.prince.respository.*;


@Component
public class StudentService {
	private final StudentRepository studentRepository;

    @Autowired  // Constructor-based DI (recommended)
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public void addStudent(Student student) {
        studentRepository.addStudent(student);
    }

    public void displayAllStudents() {
        System.out.println("All Students:");
        for (Student s : studentRepository.findAll()) {
            System.out.println(s);
        }
    }
}
