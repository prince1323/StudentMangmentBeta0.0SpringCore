package com.prince;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.prince.cfg.AppConfig;
import com.prince.model.Student;
import com.prince.service.StudentService;


public class StudentMngUserInterface 
{
    public static void main( String[] args )
    {
    	AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

         StudentService service = ctx.getBean(StudentService.class);

         service.addStudent(new Student(1, "Ravi", 12));
         service.addStudent(new Student(2, "Bob", 10));

         service.displayAllStudents();
    }
}
